<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Storitev;
use App\Komentar;

class KomentarController extends Controller{

	/*
	public funciton index(){
	//
	}
	*/

	/*
	public funciton crate(){
	//
	}
	*/

	public function store(Request $request, $komentar_storitev_id)
    {
		$this->validate($request,[
            
            'komentar'=>'required|max:1000'
            
        ]);
		
		$komentar = new Komentar();
		$komentar->komentar = $request->input('komentar');
		$komentar->post()->associate($komentar_storitev);
		
		$komentar->save();
		
		return redirect ('/komentar');
		
		
		
		}
		
		/*
		public funciton show($id){
		//
		}
		*/

}