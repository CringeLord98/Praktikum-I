<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>
<?php $__currentLoopData = $narocila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $narocilo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 


<div class="row" style="height:1em;"></div>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
        <div class="row" style="margin-bottom:0;">
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Naziv storitve: <span style="color:black;"><?php echo e($narocilo->s_naziv); ?></span></h5>
            </div>
            <div class="col s9 l3 offset-l3">
                    <h5 class="green-text text-darken-3">Številka naročila: <span style="color:black;"><?php echo e($narocilo->n_id); ?></span></h5>
                </div>
        </div>
        <div class="divider">
    
        </div>
        <div class="row">
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Naročnik: <span style="color:black;"><?php echo e($narocilo->ime); ?> <?php echo e($narocilo->priimek); ?></span></h5>
            </div>
            
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Email: <span style="color:black;"><?php echo e($narocilo->email); ?></span></h5>
             </div>
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Datum naročila: <span style="color:black;"><?php echo e($narocilo->created_at); ?></span></h5>
             </div>
             <div class="col s12 l6 ">
                <h5 class="red-text text-darken-3">Datum pričetka dela: <span style="color:black;"><?php echo e($narocilo->datum_zacetka); ?></span></h5>
            </div>
            <div class="col s12 l6 ">
                <h5 class="red-text text-darken-3">Datum konca dela: <span style="color:black;"><?php echo e($narocilo->datum_konca); ?></span></h5>
            </div>
             
            
        </div>
        <div class="divider">
    
        </div>
        <div class="row">
                <div class="col s12 l6">
                    <h5 class="green-text text-darken-3">Telefon: <span style="color:black;"><?php echo e($narocilo->telefon); ?></span></h5>
                </div>
                
                <div class="col s12 l6">
                    <h5 class="green-text text-darken-3">Okvirna cena: <span style="color:black;"><?php echo e($narocilo->okvirna_cena); ?></span></h5>
                 </div>
                <div class="col s12 l12">
                    <h5 class="green-text text-darken-3">Komentar: </h5>
                    <p><?php echo e($narocilo->komentar); ?></p>
                 </div>
                 
                 
                
            </div>
            <?php if($narocilo->stanje==1): ?>
            <div class="row">
                <div class="col s8 l10">
                <form action="<?php echo e(route('zavrni', $narocilo->n_id)); ?>" method="POST" type="hidden" name="_token"><?php echo e(csrf_field()); ?>

                <button type="submit" class=" btn btn-large btn-cancle waves-effect waves-light">
                    Zavrni
                 </button>
                </form>
                </div>
                <div class="col s2 l2">
                <form action="<?php echo e(route('odobri', $narocilo->n_id)); ?>" method="POST" type="hidden" name="_token"><?php echo e(csrf_field()); ?>

                <button type="submit" class=" btn btn-large  waves-effect waves-light">
                    Odobri
                 </button>
                </form>
                </div>
            </div>
            <?php endif; ?>

            <?php if($narocilo->stanje==2): ?>
            <h2 style="background-color:MediumSeaGreen;">Sprejeto</h2>
            <?php endif; ?>

            <?php if($narocilo->stanje==3): ?>
            <h2 style="background-color:Tomato;">Zavrnjeno</h2>
            <?php endif; ?>
    </div>



            
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>