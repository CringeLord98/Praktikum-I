<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>

<form class="col s12" action="<?php echo e(route('razvrsti')); ?>" method="POST" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <?php echo e(csrf_field()); ?>

    <select name="razvrsti">
        <option id="dis" value="1">V čakanju</option>
        <option value="2">Sprejeta</option>
        <option value="3">Zavrnjena</option>
    </select>
    <button class="btn waves-effect waves-light btn-large btnMegaSearch" type="submit" name="action">Razvrsti </button>
</form>
<?php $__currentLoopData = $narocila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $narocilo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<div class="row" style="height:1em;"></div>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
    <div class="row" style="margin-bottom:0;">
        <div class="col s12 l6">
            <h5 class="green-text text-darken-3">Naziv storitve: <span style="color:black;"><?php echo e($narocilo->s_naziv); ?></span></h5>
        </div>
        <div class="col s9 l3 offset-l3">
                <h5 class="green-text text-darken-3">Številka naročila: <span style="color:black;"><?php echo e($narocilo->n_id); ?></span></h5>
            </div>
    </div>
    <div class="divider">

    </div>
    <div class="row">
        <div class="col s12 l12">
            <h5 class="green-text text-darken-3">Naročnik: <span style="color:black;"><?php echo e($narocilo->ime); ?> <?php echo e($narocilo->priimek); ?></span></h5>
        </div>
        
        <div class="col s12 l12">
            <h5 class="green-text text-darken-3">Datum naročila: <span style="color:black;"><?php echo e($narocilo->created_at); ?></span></h5>
         </div>
        <div class="col s12 l9">
            <h5 class="red-text text-darken-3">Datum roka: <span style="color:black;"><?php echo e($narocilo->datum_konca); ?></span></h5>
         </div>
         <div class="col s12 l3">
                <a href="/narocila/<?php echo e($narocilo->n_id); ?>" class="waves-effect waves-light btn btn-large">Podrobnosti</a>
             </div>
        
    </div>
    

</div>          
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>