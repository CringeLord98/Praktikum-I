<?php $__env->startSection('Logo'); ?>
Prijava
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>
<div style="height:10em;"></div>
<div class="container">
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="input-field">
                <input id="email" type="email"  name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
                
            </div>
        </div>

        <div class="row">
            <div class="input-field">
                <input id="password" type="password"  name="password" required>
                <label for="password"><?php echo e(__('Password')); ?></label>
                
            </div>
        </div>

        <div class="row">
            <div class="col s8">
                    <?php if($errors->has('email')): ?>
                    <span class="invalid1">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                    <?php if($errors->has('password')): ?>
                    <span class="invalid1">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="col s4">
                <button type="submit" class="btn btn-large btnReg"><i class="material-icons left">check</i>
                    <?php echo e(__('Prijavi')); ?>

                </button>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>