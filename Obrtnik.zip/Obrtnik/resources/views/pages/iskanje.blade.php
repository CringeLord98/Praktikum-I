@extends('layouts.Lfooter')
@extends('layouts.Lmain')
@section('Title')
    <title>Moj Obrtnik | Iskanje</title>
@endsection
@section('Logo')
    Iskanje
@endsection
@section('Content')

      <div class="row">
        <div style="height:5em;">

        </div>
        <div class="col s10 offset-s1">
                <form class="col s12" action="{{ route('IskanjeMain') }}" method="POST" type="hidden" name="_token" value="{{ csrf_token() }}">
                        {{ csrf_field() }}
                <div class="row">
                    
                <div class="input-field col s6">
                        <select name="kategorija">
                            <option value="k.id">Vse</option>
                        @foreach($kategorije as $kategorija)
                            <option value="{{$kategorija->id}}">{{$kategorija->naziv}}</option>
                        @endforeach 
                        </select>
                        <label>Kategorija</label>
                    </div>  
                    <div class="input-field col s6">
                    <select id="regija" name="regija">
                            <option value="u.regija_id">Vse</option>
                        @foreach($regije as $regija)
                            <option value="{{$regija->id}}">{{$regija->regija}}</option>
                        @endforeach 
                    </select>
                        <label>Regija</label>
                    </div>  
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <select name="razvrsti">
                            <option id="dis" value="1">Oceni</option>
                            <option id="dis" value="4">Priljubljenosti</option>
                            <option value="2">Datumu: novejše</option>
                            <option value="3">Datumu: starejše</option>
                        </select>
                        <label>Razvrsti po:</label>
                    </div>
                       
                </div>
                <div class="row">
                    <div class="col s4">   
                    </div>
                    <div class="col s6">
                            <button class="btn waves-effect waves-light btn-large btnMegaSearch" type="submit" name="action">
                                Išči
                            </button>
                    </div>     
                </div>
            </form>
        </div>
      </div>
      @foreach($storitve as $storitev)
        <div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto;margin-bottom:3em;">
            <div class="row" style="margin-bottom:0;">
                <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Storitev: <span style="color:black;"><a href='/storitve/{{$storitev->id}}'>{{$storitev->naziv}}</a></span></h5>
                </div>
            </div>
            <div class="divider">

            </div>
            <div class="row">
                <div class="col s12 ">
                    <h5 class="green-text text-darken-3">Datum nastanka:<span style="color:black;">{{$storitev->created_at}}</span></h5>
                </div>
                <div class="col s12 l8">
                    <h5 class="green-text text-darken-3">Kategorija: <span style="color:black;">{{$storitev->k_naziv}}</span></h5>
                </div>
                <div class="col s12 l8">
                    <h5 class="green-text text-darken-3">Regija: <span style="color:black;">{{$storitev->r_naziv}}</span></h5>
                </div>
                <div class="col s12 l8">
                    <h5 class="green-text text-darken-3">Ocena: <span style="color:black;">{{$storitev->avg_ocena}}</span></h5>
                </div>
                
                
            </div>
            <img src="storage/cover_images/{{$storitev->slika}}" style="width:10em;height:10em;"></img>

        </div>
@endforeach
      <div class="divider">    
    </div>
    <h5>Kategorija:  {{ $kategorija or "Vnesite kategorijo" }}</h5>
    <h5>Kraj:  {{ $kraj or "Vnesite kraj" }}</h5>
    


@endsection
