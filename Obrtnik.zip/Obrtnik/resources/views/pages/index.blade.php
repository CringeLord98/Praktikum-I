@extends('layouts.Lfooter')
@extends('layouts.Lmain')

@section('Title')
    <title>Moj Obrtnik | Domov</title>
@endsection
@section('Logo')
    Moj Obrtnik
@endsection
@section('Slika')
    <div class="row" >
            <div class="col s12" id="indexPicutre">
                    <h1 class="center-align green-text text-darken-3" id="indexPictureText" style="margin-top:2.5em;">Vaša spletna obrtniška delavnica</h1>
            </div>
    </div>
 @endsection
@section('Content')

@guest
@else
        @if(count($narocila)>0)
                <text>{{count($narocila)}} novih narocil!</text>
        @endif
@endguest
<h4>tuki nej ne bo iskanja, sj je na onem zavihku. nej bo kle opis strani pa navodila al pa neki</h4>
<!--
    <div class="row" >
            <div class="col s12" id="indexMegaSearch">
                    <h4 class="center-align text-grey text-darken-4"id="fntFrancois">Kaj danes iščete?</h4>
            </div>
    </div>
    <br>
      <div class="row">
        <div class="col s10 offset-s1">
           
            <form class="col s12" action="{{ route('IskanjeMain') }}" method="POST" type="hidden" name="_token" value="{{ csrf_token() }}">
                    {{ csrf_field() }}
            <div class="row">
                <div class="col s6 input-field">
                        <i class="material-icons prefix">search</i>
                        <input id="icon_prefix" type="text" class="validate" name="kategorija">
                        <label for="icon_prefix">Kategorija</label>
                </div>
                <div class="col s6 input-field">
                        <i class="material-icons prefix">location_on</i>
                        <input id="icon_prefix" type="text" class="validate" name="kraj">
                        <label for="icon_prefix">Kraj</label>
                </div>       
            </div>
            <div class="row">
                <div class="col s4">   
                </div>
                <div class="col s6">
                        <button class="btn waves-effect waves-light btn-large btnMegaSearch" type="submit" name="action">
                            Išči
                        </button>
                </div>     
            </div>
        </form>
        </div>
    
       
      </div>
      <div class="divider">
      
    </div> -->
@endsection



