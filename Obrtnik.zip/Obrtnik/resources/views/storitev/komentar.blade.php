@extends('layouts.Lmain')

@selection('content')

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			@foreach($post->komentar as $komentar)
				<div class="komentar">
					<p><strong>Komentar:</strong></br>{{$komentar->komentar}}</p>
				</div>				
			@endforeach
		</div
	</div>
	
	
	
	
<div class="row">
	<div id="comment-form" class="col-md-8 col-md-offset-2">
		{{ Form::open(['route' => ['komentar.storitev', $komentar_storitev->id], 'method' => 'POST']) }}
			<div class="row">
				<div class="col-md-12">
					{{Form::label('komentar', "Komentar:") }}
					{{Form::textarea('komentar', null, ['class' => 'form-control']) }}
					
					{{Form::submit('Dodaj komentar', ['class' => 'btn btn-success btn-block', 'style' => 'margin-top:15px;']) }}
		
		
		        </div>
		            {{Form::close()}}
            </div>
	</div>
</div>