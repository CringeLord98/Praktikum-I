@extends('layouts.Lfooter')
@extends('layouts.Lmain')
@section('Title')
    <title>Moj Obrtnik | Iskanje</title>
@endsection
@section('Logo')
    Iskanje
@endsection

@section('Content')
@foreach($storitve as $storitev)
    <text>Naziv: </text>{{$storitev->s_naziv}} <br>
    <text>Opis: </text>{{$storitev->opis}} <br>
    <text>Naloženo: </text>{{$storitev->created_at}} <br>
    <text>Obrtnik: </text>{{$storitev->name}} {{$storitev->surname}}<br>
    <text>Kategorija: </text>{{$storitev->k_naziv}} <br>
    <text>Regija: </text>{{$storitev->r_naziv}} <br>
    <text>Ocena: </text>{{$storitev->avg_ocena}} <br>
    <img src="/storage/cover_images/{{ $storitev->slika }}" style="width:10em;height:10em;"></img>

    <form action="{{ route('oceni', $storitev->id) }}" method="POST" type="hidden" name="_token">
    {{ csrf_field() }}
        <select name="ocena">
                    <option value="1">Slabo</option>
                    <option value="2">Zadovoljivo</option>
                    <option value="3">Odlično</option>
                    <option value="4">Perfektno</option>
        </select>
        <button type="submit"class="waves-effect waves-light btn btn-large">Oceni</button>
    </form>

    <a href='/storitve/{{$storitev->id}}/narocilo'>Naroci</a>
    @if($errors->any())
        <h4>{{$errors->first()}}</h4>
    @endif
@endforeach
@endsection
