<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ocena extends Model
{
    protected $table = 'ocenas';

    public function ocena_storitev() {
        return $this->belongsTo('App/Storitev');
    }
}
