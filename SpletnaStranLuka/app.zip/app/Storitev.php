<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Storitev extends Model
{
    protected $table = 'storitevs';

    public function storitev_narocilo() {
        return $this->belongsTo('App/Narocilo');
    }

    public function storitev_komentar() {
        return $this->hasMany('App/Komentar');
    }

    public function storitev_ocena() {
        return $this->hasMany('App/Ocena');
    }

    public function storitev_kategorija() {
        return $this->belongsTo('App/Kategorija');
    }
}
