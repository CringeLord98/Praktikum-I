<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Narocilo extends Model
{
    protected $table = 'narocilos';

    public function narocilo_user() {
        return $this->belongsTo('App/User');
    }

    public function narocilo_stanje() {
        return $this->belongsTo('App/StanjeNarocila');
    }

    public function narocilo_storitev() {
        return $this->belongsTo('App/Storitev');
    }
}
