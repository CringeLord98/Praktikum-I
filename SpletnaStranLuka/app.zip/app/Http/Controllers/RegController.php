<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Obrtnik;

class RegController extends Controller
{
    public function Register(Request $request){

        $this->validate($request,
        [  'uIme' => 'max:45',
           'ime' => 'max:45',
           'priimek' => 'max:45',
           'email' => 'max:45',
           'geslo' => 'max:45',
           'geslo2' => 'required_with:geslo|same:geslo|max:45',
           'davcna' => 'max:8|min:8',
           'telefon' => 'max:45'

    ],
        [
          'uIme.max' => 'Vnesite ime pod 45 črkami.',

          
          'ime.max' => 'Vnesite ime pod 45 črkami.',

          
          'priimek.max' => 'Vnesite ime pod 45 črkami.',

          
          'email.max' => 'Vnesite ime pod 45 črkami.',

         
          'geslo.max' => 'Vnesite ime pod 45 črkami.',

          
          'geslo2.max' => 'Vnesite ime pod 45 črkami.',

         
          'davcna.max' => 'Vnesite 8-mestno davčno številko.',
          'davcna.min' => 'Vnesite 8-mestno davšno številko',

          'telefon.max' => 'Vnesite ime pod 5 črkami.',

          'geslo2.same' => 'Gesli se morata ujemati'
        ]);
    
    $obrtnik = new Obrtnik;
    $obrtnik->Ime =$request->input('ime');
    $obrtnik->Priimek =$request->input('priimek');
    $obrtnik->Davcna =$request->input('davcna');
    $obrtnik->Email =$request->input('email');
    $obrtnik->Telefon =$request->input('telefon');
    $obrtnik->Username =$request->input('uIme');
    $obrtnik->Password =$request->input('geslo2');
    $obrtnik->save();
    }
}
