<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNarocilosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('narocilos', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('okvirna_cena');
            $table->date('datum_narocila');
            $table->string('komentar');
            $table->string('telefon');
            $table->date('datum_zacetka');
            $table->date('datum_konca');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('narocilos');
    }
}
