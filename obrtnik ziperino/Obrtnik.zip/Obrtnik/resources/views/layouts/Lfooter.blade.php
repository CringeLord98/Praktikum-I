<footer class="page-footer green darken-3">
    <div class="container">
      <div class="row">
        <div class="col l4 s12">
          <h5 class="white-text">Moj Obrtnik</h5>
          <a href=""><p class="grey-text text-lighten-4">Zasebnost podatkov</p></a>
          <a href=""><p class="grey-text text-lighten-4">Pogosta vprašanja</p></a>
          <a href=""><p class="grey-text text-lighten-4">Pogoji uporabe</p></a>
          <a href=""><p class="grey-text text-lighten-4">O nas</p></a>
        </div>
        <div class="col l4 s12">
            <h5 class="white-text">Pomoč</h5>
            <a href=""><p class="grey-text text-lighten-4">Začetek</p></a>
            <a href=""><p class="grey-text text-lighten-4">O kategorijah</p></a>
            <a href=""><p class="grey-text text-lighten-4">Postati obrtnik</p></a>
            <a href=""><p class="grey-text text-lighten-4">Delavnica uporabnikom</p></a>
          </div>
          <div class="col l4 s12">
              <h5 class="white-text">Skupnost</h5>
              <a href=""><p class="grey-text text-lighten-4">Forum</p></a>
              <a href=""><p class="grey-text text-lighten-4">Facebook</p></a>
              <a href=""><p class="grey-text text-lighten-4">Kontaktirajte nas</p></a>
              <a href=""><p class="grey-text text-lighten-4">Blog</p></a>
            </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      © 2018 Copyright Obrtnik.si

      </div>
    </div>
  </footer>