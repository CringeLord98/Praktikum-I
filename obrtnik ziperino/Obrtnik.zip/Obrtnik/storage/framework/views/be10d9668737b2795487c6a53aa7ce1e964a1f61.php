<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Iskanje</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?>
    Iskanje
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>
<div class="container white" id="mainContainer" style="min-height:42.7em;">
<?php $__currentLoopData = $storitve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storitev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container" style="background-color:wheet; margin-top:1em;margin-bottom:2em;">
            <div style="height:4em; margin-bottom:1em;">
                <div class="container" style="width:30%;">
                        <?php if($errors->any()): ?>
                        <script>Materialize.toast('<i class="material-icons left">check</i><?php echo e($errors->first()); ?>', 4000,'green darken-3')</script>
                        <?php endif; ?>      
                </div> 
            </div>
            <div class="">
                    <div class="row">
                            <div class="col s12 m12">
                              <div class="card hoverable">
                                <div class="card-image" >
                                  <img src="/storage/cover_images/<?php echo e($storitev->s_slika); ?>" >
                                  <?php if(Auth::check()): ?>
                                  <?php if(auth()->user()->id==$storitev->user_id): ?>

                                  <?php else: ?>
                                  <a class="btn-floating halfway-fab pulse waves-effect waves-light green darken-3 tooltipped" data-position="left" href="/storitve/<?php echo e($storitev->id); ?>/narocilo" data-delay="50" data-tooltip="Naroči na storitev"><i class="material-icons">add</i></a>
                                  <?php endif; ?>
                                  <?php else: ?>
                                  <a class="btn-floating halfway-fab pulse waves-effect waves-light green darken-3 tooltipped" data-position="left" href="/storitve/<?php echo e($storitev->id); ?>/narocilo" data-delay="50" data-tooltip="Naroči na storitev"><i class="material-icons">add</i></a>
                                  <?php endif; ?>
                                </div>
                                <div class="card-content">
                                        <span class="card-title"><?php echo e($storitev->s_naziv); ?></span>
                                </div>
                        </div>

                        <ul class="collapsible popout hoverable" data-collapsible="accordion" style="border:0;box-shadow:0;">
                                <li class="active">
                                  <div class="collapsible-header active"><i class="material-icons">info</i>Opis Storitve</div>
                                  <div class="collapsible-body">
                                      <div class="row">
                                        <div class="col s12 l12"><p><?php echo e($storitev->opis); ?></p></div>
                                        <div class="col s12 l6">
                                            <b style="font-size:1.1em;">Kategorija: </b><p><?php echo e($storitev->k_naziv); ?></p>
                                        </div>
                                        <div class="col s12 l6">
                                                <b style="font-size:1.1em;">Datum nastanka:</b><p><?php echo e(Carbon\Carbon::parse($storitev->created_at)->format('d.m.Y')); ?></p>
                                            </div>
                                    </div>
                                        <div class="row">
                                            <div class="col s12 l6">
                                                <p>
                                                    <b style="font-size:1.1em;">Ocena: </b>
                                                    <div class="progress">
                                                    <div class="determinate" style="width: <?php echo e($storitev->avg_ocena); ?>%;background-color:
                                                        <?php if($storitev->avg_ocena<20): ?>
                                                        #d50000
                                                        <?php endif; ?>
                                                        <?php if($storitev->avg_ocena<40 and $storitev->avg_ocena >=20): ?>
                                                        #e65100
                                                        <?php endif; ?>
                                                        <?php if($storitev->avg_ocena<60 and $storitev->avg_ocena >=40): ?>
                                                        #ffea00
                                                        <?php endif; ?>
                                                        <?php if($storitev->avg_ocena<80 and $storitev->avg_ocena >=60): ?>
                                                        #aeea00
                                                        <?php endif; ?>
                                                        <?php if($storitev->avg_ocena<100 and $storitev->avg_ocena >=80): ?>
                                                        #388e3c
                                                        <?php endif; ?>
                                                        "></div>
                                                    </div></p>                                                   
                                            </div>
                                            <div class="col s12 l6">
                                                    <b style="font-size:1.1em;">Regija:</b><p><?php echo e(($storitev->r_naziv)); ?></p>
                                              </div>
                                        </div>
                                        
                                      
                                  </div>
                                </li>
                                <li>
                                  <div class="collapsible-header"><i class="material-icons">person</i>Avtor</div>
                                  <div class="collapsible-body">
                                        <div class="row">
                                                <div class="col s12 l4">
                                                  <div class="card">
                                                  <?php if($storitev->u_slika=="noprofile.png"): ?>
                                                  <div class="card-image">
                                                            <img src="/storage/cover_images/<?php echo e($storitev->u_slika); ?>"></img>
                                                            <br>                                
                                                    <span class="card-title black-text"><?php echo e($storitev->name); ?> <?php echo e($storitev->surname); ?></span>
                                                    </div>
                                                  <?php else: ?>
                                                  <div class="card-image">
                                                            <img src="/storage/cover_images/<?php echo e($storitev->u_slika); ?>"></img>
                                                    <span class="card-title"><?php echo e($storitev->name); ?> <?php echo e($storitev->surname); ?></span>
                                                    </div>
                                                  <?php endif; ?>
                                                    
                                                  </div>
                                                </div>
                                                <div class="col s12 l8">
                                                        <p><?php echo e($storitev->u_opis); ?></p>
                                                </div>
                                        </div>
                                  </div>
                                </li>
                        </ul>

                        <div class="row">
                        <?php if(Auth::check()): ?>
                        <?php if(auth()->user()->id==$storitev->user_id): ?>

                        <?php else: ?>
                                <form action="<?php echo e(route('oceni', $storitev->id)); ?>" method="POST" type="hidden" name="_token">
                            <div class="col s12 l6 offset-l2">                                  
                                            <?php echo e(csrf_field()); ?>

                                            <p class="range-field">
                                                    <input name="ocena"type="range" id="test5" min="1" max="10" />
                                            </p>
                                                   
                            </div>
                            <div class="col s12 l4">
                                    <button type="submit"class="waves-effect waves-light btn btn-large"><i class="material-icons left">grade</i>Oceni</button>  
                            </div>
                        </form>
                        <?php endif; ?>
                        <?php else: ?>
                        <form action="<?php echo e(route('oceni', $storitev->id)); ?>" method="POST" type="hidden" name="_token">
                            <div class="col s12 l6 offset-l2">                                  
                                            <?php echo e(csrf_field()); ?>

                                            <p class="range-field">
                                                    <input name="ocena"type="range" id="test5" min="1" max="10" />
                                            </p>
                                                   
                            </div>
                            <div class="col s12 l4">
                                    <button type="submit"class="waves-effect waves-light btn btn-large"><i class="material-icons left">grade</i>Oceni</button>  
                            </div>
                        </form>
                        <?php endif; ?>
                              </div>
                            </div>
                          </div>
                          
            </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>