<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Iskanje</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?>
    Iskanje
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>
<div class="container white" id="mainContainer" style="min-height:42.7em;">
<div class="row">
        <div style="height:5em;">
                
        </div>
        <div class="col s10 offset-s1">
                <form class="col s12" action="<?php echo e(route('IskanjeMain')); ?>" method="POST" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo e(csrf_field()); ?>

                <div class="row">
                    
                <div class="input-field col s6">
                    <select name="kategorija">
                        <?php if($kategorija_stanje=='k.id'): ?>
                            <option value="k.id" selected='selected'>Vse</option>
                        <?php $__currentLoopData = $kategorije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kategorija->id); ?>"><?php echo e($kategorija->naziv); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php endif; ?>

                        <?php if($kategorija_stanje!='k.id'): ?>
                            <option value="k.id">Vse</option>
                        <?php $__currentLoopData = $kategorije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kategorija->id==$kategorija_stanje): ?>
                            <option value="<?php echo e($kategorija->id); ?>" selected='selected'><?php echo e($kategorija->naziv); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($kategorija->id); ?>"><?php echo e($kategorija->naziv); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php endif; ?>
                        </select>
                        <label>Kategorija</label>
                    </div>  
                    <div class="input-field col s6">
                        <select id="regija" name="regija">
                            <?php if($regija_stanje=='u.regija_id'): ?>
                                <option value="u.regija_id">Vse</option>
                            <?php $__currentLoopData = $regije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($regija->id); ?>"><?php echo e($regija->regija); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php endif; ?>
    
                            <?php if($regija_stanje!='u.regija_id'): ?>
                                <option value="u.regija_id">Vse</option>
                            <?php $__currentLoopData = $regije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($regija->id==$regija_stanje): ?>
                                <option value="<?php echo e($regija->id); ?>" selected='selected'><?php echo e($regija->regija); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($regija->id); ?>"><?php echo e($regija->regija); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php endif; ?>
                        </select>
                        <label>Regija</label>
                    </div>  
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <select name="razvrsti">
                            <?php if($razvrsti_stanje==1): ?>
                                <option id="dis" value="1" selected='selected'>Oceni</option>
                                <option id="dis" value="4">Priljubljenosti</option>
                                <option value="2">Datumu: novejše</option>
                                <option value="3">Datumu: starejše</option>
                            <?php endif; ?>
                            <?php if($razvrsti_stanje==2): ?>
                                <option id="dis" value="1">Oceni</option>
                                <option id="dis" value="4">Priljubljenosti</option>
                                <option value="2"  selected='selected'>Datumu: novejše</option>
                                <option value="3">Datumu: starejše</option>
                            <?php endif; ?>
                            <?php if($razvrsti_stanje==3): ?>
                                <option id="dis" value="1">Oceni</option>
                                <option id="dis" value="4">Priljubljenosti</option>
                                <option value="2">Datumu: novejše</option>
                                <option value="3"  selected='selected'>Datumu: starejše</option>
                            <?php endif; ?>
                            <?php if($razvrsti_stanje==4): ?>
                                <option id="dis" value="1">Oceni</option>
                                <option id="dis" value="4"  selected='selected'>Priljubljenosti</option>
                                <option value="2">Datumu: novejše</option>
                                <option value="3">Datumu: starejše</option>
                            <?php endif; ?>
                            </select>
                        <label>Razvrsti po:</label>
                    </div>
                       
                </div>
                <div class="row">
                    <div class="col s4">   
                    </div>
                    <div class="col s6">
                            <button class="btn waves-effect waves-light btn-large btnMegaSearch" type="submit" name="action"><i class="material-icons left">search</i>
                                Išči
                            </button>
                    </div>     
                </div>
            </form>
        </div>
      </div>
      <div class="divider">

      </div>
      <div style="height:3em;"></div>
      <?php $__currentLoopData = $storitve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storitev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <div class="row">
            <div class="col s12 l8 offset-l2">
              <div class="card white lighten-4 hoverable" style="border:1px solid #2e7d327c;">
                <div class="card-content grey-text text-darken-3">
                  <span class="card-title green-text text-darken-3"><?php echo e($storitev->naziv); ?></span>
              
                  <div class="row">
                      <div class="col l6 s12">
                        <b>Kategorija:</b><p><?php echo e($storitev->k_naziv); ?></p>
                      </div>
                      <div class="col l6 s12">
                        <b>Regija:</b><p><?php echo e($storitev->r_naziv); ?></p>
                        </div>
                        
                  </div>
                  <div class="row">
                        <div class="col l6 s12">
                                <p>
                                        <b style="font-size:1.1em;">Ocena: </b>
                                        <div class="progress">
                                        <div class="determinate" style="width: <?php echo e($storitev->avg_ocena); ?>%;background-color:
                                            <?php if($storitev->avg_ocena<20): ?>
                                            #d50000
                                            <?php endif; ?>
                                            <?php if($storitev->avg_ocena<40 and $storitev->avg_ocena >=20): ?>
                                            #e65100
                                            <?php endif; ?>
                                            <?php if($storitev->avg_ocena<60 and $storitev->avg_ocena >=40): ?>
                                            #ffea00
                                            <?php endif; ?>
                                            <?php if($storitev->avg_ocena<80 and $storitev->avg_ocena >=60): ?>
                                            #aeea00
                                            <?php endif; ?>
                                            <?php if($storitev->avg_ocena<100 and $storitev->avg_ocena >=80): ?>
                                            #388e3c
                                            <?php endif; ?>
                                            "></div>
                                        </div></p>
                        </div>
                        <div class="col l6 s12">
                          <b>Datum nastanka:</b><p><?php echo e(Carbon\Carbon::parse($storitev->created_at)->format('d.m.Y')); ?></p>
                          </div>
                    </div>
                </div>
                <div class="card-action right-align">
                        <a href="/storitve/<?php echo e($storitev->id); ?>" class="waves-effect waves-light btn btn-large"><i class="material-icons left">more_vert</i>Podrobnosti</a>
                </div>
              </div>
            </div>
          </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.Lfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>