use mojobrtnik;

insert into stanje_narocila values(null, 'V čakanju');
insert into stanje_narocila values(null, 'Sprejeto');
insert into stanje_narocila values(null, 'Zavrnjeno');

insert into regija values(null, 'Osrednjeslovenska');
insert into regija values(null, 'Podravska');
insert into regija values(null, 'Savinjska');
insert into regija values(null, 'Pomurska');
insert into regija values(null, 'Gorenjska');
insert into regija values(null, 'Koroška');
insert into regija values(null, 'Goriška');
insert into regija values(null, 'Jugo-vzhodna Slovenija');
insert into regija values(null, 'Primorsko-Notranjska');
insert into regija values(null, 'Obalno-kraška');
insert into regija values(null, 'Zasavska');
insert into regija values(null, 'Posavska');

insert into kategorija values(null, 'Frizerstvo');
insert into kategorija values(null, 'Kovaštvo');
insert into kategorija values(null, 'Avtoličarstvo');