@extends('layouts.Lmain')

@section('Title')
    <title>Moj Obrtnik | Profil</title>
@endsection
@section('Logo') 
{{ Auth::user()->name }}
@endsection

@section('Content')


    
<div class="row" style="height:1em;"></div>
@if(count($storitve)>0)     
        @foreach($storitve as $storitev)
        <div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto;margin-bottom:3em;">
            <div class="row" style="margin-bottom:0;">
                <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Storitev: <span style="color:black;">{{$storitev->naziv}}</span></h5>
                </div>
            </div>
            <div class="divider">

            </div>
            <div class="row">
                <div class="col s12 ">
                    <h5 class="green-text text-darken-3">Datum nastanka:<span style="color:black;">{{$storitev->created_at}}</span></h5>
                </div>
                <div class="col s12 l8">
                    <h5 class="green-text text-darken-3">Kategorija: <span style="color:black;">{{$storitev->k_naziv}}</span></h5>
                </div>
                
                <div class="col s12 l2">
                    <a href='/storitve/{{$storitev->id}}/edit' class="waves-effect waves-light btn btn-large">Uredi</a>
                </div>
                <form action="{{ route('destroy', $storitev->id) }}" method="POST" type="hidden" name="_token">
                        {{ csrf_field() }}
                {{Form::hidden('_method','DELETE')}}
                <div class="col s12 l2">
                    <button href="{{ url('/narocilo') }}" type="submit" class="waves-effect waves-light btn btn-large btn-Cancle">Izbriši</bnutton>
                </div>
                </form>  
                
            </div>
            <img src="storage/cover_images/{{$storitev->slika}}" style="width:10em;height:10em;"></img>

        </div>
@endforeach
@else
<div style=margin-top:5em;margin-bottom:3em;>
    <h5 class="grey-text text-darken-3 center-align">Nimate storitev.</h5>
<div>
@endif




<div class="divider" style="width:80%;margin:auto;"></div>  
<div style="margin-top:2em;">
</div>
<div class="row">
    <div class="col s12 center-align">
        <a href="{{ url('/storitve/create') }}" class="waves-effect waves-light btn btn-large">Dodaj storitev</a>
    </div>
</div>
            

@endsection

