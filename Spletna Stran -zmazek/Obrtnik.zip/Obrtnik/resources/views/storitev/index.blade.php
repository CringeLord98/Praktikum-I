@extends('layouts.Lmain')

@section('Title')
    <title>Moj Obrtnik | Profil</title>
@endsection
@section('Logo') 
{{ Auth::user()->name }}
@endsection

@section('Content')

<a href='/storitve/create'>create</a>
    <table>
        <tr>
            <th>Title</th>
            <th></th>
            <th></th>
        </tr>
        @foreach($storitve as $storitev)
        <tr>
            <th>{{$storitev->naziv}}</th>
            <th><a href='/storitve/{{$storitev->id}}/edit'>edit</a></th>
            <th>
                <form action="{{ route('destroy', $storitev->id) }}" method="POST" type="hidden" name="_token">
                {{ csrf_field() }}
                    {{Form::hidden('_method','DELETE')}}
                    <button class="btn waves-effect waves-light" type="submit" name="action">Submit
                                <i class="material-icons right">send</i>
                              </button>
                </form>  
            </th>
        </tr>
        @endforeach
       </table>
@endsection





