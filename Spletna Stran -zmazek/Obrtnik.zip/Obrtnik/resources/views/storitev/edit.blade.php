@extends('layouts.Lmain')

@section('Title')
    <title>Moj Obrtnik | Profil</title>
@endsection
@section('Logo') 
{{ Auth::user()->name }}
@endsection

@section('Content')


    
<div class="row" style="height:1em;"></div>

<form action="{{ route('update', $storitev->id) }}" method="POST" type="hidden" name="_token">
{{ csrf_field() }}

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
    <div class="row">
            <div class="input-field col s10 offset-s1">
                <input id="first_name" type="text" class="validate" name="naziv">
                <label for="first_name">{{$storitev->naziv}}</label>
              </div>
        
    </div>
    <div class="row">
            <div class="input-field col s10 offset-s1">
                  <textarea id="textarea1" class="materialize-textarea" name="opis"></textarea>
                  <label for="textarea1">{{$storitev->opis}}</label>
            </div>
    </div>
    <div class="row">
        <div class="input-field col s10 offset-s1">
                <select name="kategorija">
                    @foreach($kategorije as $kategorija)
                        <option value="{{$kategorija->id}}">{{$kategorija->naziv}}</option>
                    @endforeach   
                </select>
            <label>Materialize Select</label>
        </div>   
            
        </div>
        <div class="row">
                <div class="file-field input-field col s10 offset-s1">
                    <div class="btn">
                          <span>Slika</span>
                          <input type="file" >
                          </div>
                          <div class="file-path-wrapper">
                          <input class="file-path validate" type="text" placeholder="Izberite sliko">
                    </div>
                </div>
        </div>
        {{Form::hidden('_method','PUT')}}
        <button class="btn waves-effect waves-light" type="submit" name="action">Submit
                                <i class="material-icons right">send</i>
                              </button>
    </div>
    
   
</div>
</form>     

<div style="margin-top:5em;">
        
</div>
  


            

@endsection

