<html>
    <head>
            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
            <link href="https://fonts.googleapis.com/css?family=Bree+Serif|Francois+One|Indie+Flower|Kaushan+Script|Open+Sans|Roboto" rel="stylesheet">
            <link rel="stylesheet" type="text/css" href="{{ url('/css/materialize.min.css') }}" />
            <link rel="stylesheet" type="text/css" media="screen" href="{{ url('/css/styles.css') }}" />
    </head>
    <body>
      <div class="input-field col s12">
      <select>
            <option value="" disabled selected>Choose your option</option>
            <option value="1">Option 1</option>
            <option value="2">Option 2</option>
            <option value="3">Option 3</option>
          </select>
          <label>Materialize Select</label>
        </div>
                                    

    </body>
    
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
    <script>
      $(document).ready(function() {
      $('select').material_select();
      });
    </script>


</html>
