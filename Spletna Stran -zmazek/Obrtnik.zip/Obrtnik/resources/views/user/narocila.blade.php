@extends('layouts.Lmain')

@section('Title')
    <title>Moj Obrtnik | Profil</title>
@endsection
@section('Logo') 
{{ Auth::user()->name }}
@endsection

@section('Content')


@if(count($narocila)>0)     
@foreach($narocila as $narocilo)   
<div class="row" style="height:1em;"></div>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
    <div class="row" style="margin-bottom:0;">
        <div class="col s12 l6">
            <h5 class="green-text text-darken-3">Naziv storitve: <span style="color:black;">!</span></h5>
        </div>
        <div class="col s9 l3 offset-l3">
                <h5 class="green-text text-darken-3">Številka naročila: <span style="color:black;">{{$narocilo->id}}</span></h5>
            </div>
    </div>
    <div class="divider">

    </div>
    <div class="row">
        <div class="col s12 l12">
            <h5 class="green-text text-darken-3">Naročnik: <span style="color:black;">{{$narocilo->ime}} {{$narocilo->priimek}}</span></h5>
        </div>
        
        <div class="col s12 l12">
            <h5 class="green-text text-darken-3">Datum naročila: <span style="color:black;">{{$narocilo->datum_zacetka}}</span></h5>
         </div>
        <div class="col s12 l9">
            <h5 class="red-text text-darken-3">Datum roka: <span style="color:black;">{{$narocilo->datum_konca}}</span></h5>
         </div>
         <div class="col s12 l3">
                <a href="{{ url('/narocilo') }}" class="waves-effect waves-light btn btn-large">Podrobnosti</a>
             </div>
        
    </div>
    

</div>
@endforeach
@else

<div style="margin-top:5em;">
        <h5 class="grey-text text-darken-3 center-align">Nimate naročil.</h5>
</div>
  
@endif

            

@endsection




