<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Storitev;
use App\Kategorija;
use App\Regija;
use Illuminate\Support\Facades\DB;

class IskanjeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
        $kategorije = Kategorija::all(); 
        $regije = Regija::all();

        $storitve = DB::select("SELECT s.id, s.naziv, s.opis, s.created_at, s.slika, k.naziv as k_naziv, r.regija as r_naziv, AVG(o.ocena) as avg_ocena FROM users u JOIN storitev s ON u.id = s.user_id JOIN kategorija k ON k.id = s.kategorija_id JOIN regija r ON r.id = u.regija_id LEFT JOIN ocena o ON s.id = o.storitev_id GROUP BY s.id ORDER BY s.created_at DESC");
        return view('pages.iskanje')->with(array('storitve'=> $storitve,'kategorije'=>$kategorije,'regije'=>$regije));
    }

    public function iskanje(Request $request)
    {
        $kategorije = Kategorija::all();
        $regije = Regija::all();

        $kategorija = $request->input('kategorija');
        $regija = $request->input('regija');
        $datum = $request->input('datum');
        
        $storitve = DB::select("SELECT s.id, s.naziv, s.opis, s.created_at, s.slika, k.naziv as k_naziv, r.regija as r_naziv, AVG(o.ocena) as avg_ocena FROM users u JOIN storitev s ON u.id = s.user_id JOIN kategorija k ON k.id = s.kategorija_id JOIN regija r ON r.id = u.regija_id LEFT JOIN ocena o ON s.id = o.storitev_id WHERE k.id=".$kategorija." AND u.regija_id = ".$regija." GROUP BY s.id ORDER BY s.created_at ".$datum);
        return view('pages.iskanje')->with(array('storitve'=> $storitve,'kategorije'=>$kategorije,'regije'=>$regije));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

}
