<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\User;   
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Validation\Rule;

class ProfileController extends Controller
{
    public function index(){
        
        return view('user.profileSettings');
    }
    public function profile(){
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        return view('user.profile')->with('user',$user);
    }
    public function update(Request $request){
        $user_id = auth()->user()->id;
        $user = User::find($user_id);

        $this->validate($request,[
            'name' => 'required|string|max:45',
            'surname' => 'required|string|max:45',
            'email' => 'required|string|email|max:45|unique:users,email,'.$user->id,
           // 'email' => ['required','string','email', 'max:45', Rule::unique('users')->ignore($user->id)],
            'password' => 'required|string|min:3|confirmed',
            'davcna' => 'required|string|min:8|max:8',
            'telefon' => 'required|string|min:3'
        ]);

        if($request->hasFile('slika')){
            $filenameWithExt = $request->file('slika')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('slika')->getClientOriginalExtension();
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            $path = $request->file('slika')->storeAs('public/cover_images',$fileNameToStore);
            $user->slika = $fileNameToStore;
        }
          
          
          $user->name= $request->input('name');
          $user->surname= $request->input('surname');
          $user->email = $request->input('email');
          $user->password= Hash::make($request['password']);
          $user->davcna = $request->input('davcna');
          $user->opis = $request->input('opis');
          $user->save();
        
          return redirect('/');
    }
}
