<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Storitev;
use App\Kategorija;
use Illuminate\Support\Facades\DB;

class StoritevController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $user_id = auth()->user()->id;
        //$user = User::find($user_id);
        //$storitve = $user->user_storitev()->get();
        //$storitve_kategorije = $storitve->storitev_kategorija()->join('kategorija', 'kategorija.id', '=', 'storitev.kategorija_id')->get();
        $test = DB::select("SELECT s.id, s.naziv, s.opis, s.created_at, s.slika, k.naziv as k_naziv FROM users u JOIN storitev s ON u.id = s.user_id JOIN kategorija k ON k.id = s.kategorija_id WHERE s.user_id='$user_id'");
        return view('storitev.index')->with('storitve', $test);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $kategorije = Kategorija::all();
        return view('storitev.create')->with(array('kategorije'=>$kategorije));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'naziv'=>'required|max:50',
            'opis'=>'required|max:1000',
            'slika'=>'image|nullable|max:1999'
        ]);
        $storitev = new Storitev;
        if($request->hasFile('slika')){
            $filenameWithExt = $request->file('slika')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('slika')->getClientOriginalExtension();
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            $path = $request->file('slika')->storeAs('public/cover_images',$fileNameToStore);
            $storitev->slika = $fileNameToStore;
        }
        else
        {
            $storitev->slika = 'noimage.png';
        }

        
        $storitev->naziv = $request->input('naziv');
        $storitev->opis = $request->input('opis');
        $storitev->kategorija_id = $request->input('kategorija');
        $storitev->user_id = auth()->user()->id;
        
        $storitev->save();

        return redirect ('/storitve');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $storitev=Storitev::find($id);
        $kategorije = Kategorija::all();
        return view('storitev.edit')->with(array('storitev'=> $storitev,'kategorije'=>$kategorije));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'naziv'=>'required|max:50',
            'opis'=>'required|max:1000',
            'slika'=>'image|nullable|max:1999'
        ]);
        $storitev = Storitev::find($id);
        if($request->hasFile('slika')){
            $filenameWithExt = $request->file('slika')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('slika')->getClientOriginalExtension();
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            $path = $request->file('slika')->storeAs('public/cover_images',$fileNameToStore);
            $storitev->slika = $fileNameToStore;
        }
        
        $storitev->naziv = $request->input('naziv');
        $storitev->opis = $request->input('opis');
        $storitev->kategorija_id = $request->input('kategorija');
        
        $storitev->user_id = auth()->user()->id;
        
        $storitev->save();
        
        return redirect('/storitve');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $storitev = Storitev::find($id);
        $storitev->delete();
        return redirect('/storitve');
    }
}