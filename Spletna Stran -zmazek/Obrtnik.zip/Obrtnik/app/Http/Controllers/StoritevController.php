<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Storitev;
use App\Kategorija;

class StoritevController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        return view('storitev.index')->with('storitve', $user->user_storitev()->get());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $kategorije = Kategorija::all();
        return view('storitev.create')->with(array('kategorije'=>$kategorije));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'naziv'=>'required|max:50',
            'opis'=>'required|max:1000'
        ]);

        $storitev = new Storitev;
        $storitev->naziv = $request->input('naziv');
        $storitev->opis = $request->input('opis');
        $storitev->kategorija_id = $request->input('kategorija');
        $storitev->user_id = auth()->user()->id;
        
        $storitev->save();

        return 123;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $storitev=Storitev::find($id);
        $kategorije = Kategorija::all();
        return view('storitev.edit')->with(array('storitev'=> $storitev,'kategorije'=>$kategorije));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'naziv'=>'required|max:50',
            'opis'=>'required|max:1000'
        ]);

        $storitev = Storitev::find($id);
        $storitev->naziv = $request->input('naziv');
        $storitev->opis = $request->input('opis');
        $storitev->kategorija_id = $request->input('kategorija');
        $storitev->user_id = auth()->user()->id;
        
        $storitev->save();

        return 123;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $storitev = Storitev::find($id);
        $storitev->delete();
        return 123;
    }
}
