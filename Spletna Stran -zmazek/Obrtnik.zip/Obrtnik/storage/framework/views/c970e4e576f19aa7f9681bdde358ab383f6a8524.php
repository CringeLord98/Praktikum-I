<html>
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Acces Denied</title>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Bree+Serif|Francois+One|Indie+Flower|Kaushan+Script|Open+Sans|Roboto" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/materialize.min.css')); ?>" />
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>

        
        <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(url('/css/styles.css')); ?>" />
</head>
<body class="red lighten-1 valign-wrapper center-align">
    


<div class="row" style="">
        <div class="col s12 m8 offset-m2 l8 offset-l2 ">
          <div class="card-panel pulse red darken-1">
            <span class="white-text"><h3>Acces denied</h3></span>
           
          </div>
        </div>
      </div>

</body>
</html>