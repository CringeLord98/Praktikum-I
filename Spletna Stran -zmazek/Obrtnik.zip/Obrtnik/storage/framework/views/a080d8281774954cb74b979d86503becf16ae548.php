<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>



<div class="row" style="height:1em;"></div>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
        <div class="row" style="margin-bottom:0;">
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Naziv storitve: <span style="color:black;">Mizarstvo Matjaz</span></h5>
            </div>
            <div class="col s9 l3 offset-l3">
                    <h5 class="green-text text-darken-3">Številka naročila: <span style="color:black;">1</span></h5>
                </div>
        </div>
        <div class="divider">
    
        </div>
        <div class="row">
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Naročnik: <span style="color:black;">Ana Jelen</span></h5>
            </div>
            
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Email: <span style="color:black;">Ana.Jelen@gmail.com</span></h5>
             </div>
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Datum naročila: <span style="color:black;">25.7.2017</span></h5>
             </div>
             <div class="col s12 l6 ">
                <h5 class="red-text text-darken-3">Datum roka: <span style="color:black;">25.10.2017</span></h5>
            </div>
             
            
        </div>
        <div class="divider">
    
        </div>
        <div class="row">
                <div class="col s12 l6">
                    <h5 class="green-text text-darken-3">Telefon: <span style="color:black;">051 123 321</span></h5>
                </div>
                
                <div class="col s12 l6">
                    <h5 class="green-text text-darken-3">Okvirna cena: <span style="color:black;">250€</span></h5>
                 </div>
                <div class="col s12 l12">
                    <h5 class="green-text text-darken-3">Komentar: </h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut urna augue, convallis in mollis gravida, cursus ac purus. Cras at velit imperdiet, fermentum risus in, aliquam nulla. Vivamus pulvinar a turpis vel egestas. Suspendisse molestie facilisis nulla, interdum vehicula erat condimentum sed. Praesent egestas, purus a efficitur ultricies, lorem felis pellentesque quam, eget mollis nunc neque et nisi. Integer dictum, diam id convallis bibendum, arcu ligula ullamcorper nisl, in volutpat lorem enim vitae lectus. Mauris efficitur ultricies lorem et molestie. Suspendisse vel ipsum tellus. In ac tempus augue. Sed lacus libero, malesuada nec odio ac, bibendum malesuada magna. Suspendisse potenti. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
                 </div>
                 
                 
                
            </div>
            <div class="row">
                <div class="col s8 l10">
                <a href="" class=" btn btn-large btn-cancle waves-effect waves-light"  >
                    Zavrni
                 </a>
                </div>
                <div class="col s2 l2">
                <a href="" class=" btn btn-large  waves-effect waves-light"  >
                     Odobri
                 </a>
                </div>
            </div>
        
    
    </div>



            

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>