<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Iskanje</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?>
    Iskanje
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>

      <div class="row">
        <div style="height:5em;">

        </div>
        <div class="col s10 offset-s1">
                <form class="col s12" action="<?php echo e(route('IskanjeMain')); ?>" method="POST" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo e(csrf_field()); ?>

                <div class="row">
                    
                <div class="input-field col s6">
                        <select name="kategorija">
                            <option value="k.id">Vse</option>
                        <?php $__currentLoopData = $kategorije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kategorija->id); ?>"><?php echo e($kategorija->naziv); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                        <label>Kategorija</label>
                    </div>  
                    <div class="input-field col s6">
                    <select id="regija" name="regija">
                            <option value="u.regija_id">Vse</option>
                        <?php $__currentLoopData = $regije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($regija->id); ?>"><?php echo e($regija->regija); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                        <label>Regija</label>
                    </div>  
                </div>
                <div class="row">
                    <div class="input-field col s6">
                        <select name="datum">
                        <option id="dis" value="DESC">Novejše</option>
                              <option value="ASC">Starejše</option>
                            </select>
                            <label>Razvrsti po datumu</label>
                    </div>
                    <div class="input-field col s6">
                        <select name="priljubljenost">
                            <option id="dis" value="DESC">Padajoče</option>
                            <option value="ASC">Naraščajoče</option>
                        </select>
                        <label>Razvrsti po priljubljenosti</label>
                    </div>  
                       
                </div>
                <div class="row">
                    <div class="col s4">   
                    </div>
                    <div class="col s6">
                            <button class="btn waves-effect waves-light btn-large btnMegaSearch" type="submit" name="action">
                                Išči
                            </button>
                    </div>     
                </div>
            </form>
        </div>
      </div>
      <?php $__currentLoopData = $storitve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storitev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto;margin-bottom:3em;">
            <div class="row" style="margin-bottom:0;">
                <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Storitev: <span style="color:black;"><a href='/storitve/<?php echo e($storitev->id); ?>'><?php echo e($storitev->naziv); ?></a></span></h5>
                </div>
            </div>
            <div class="divider">

            </div>
            <div class="row">
                <div class="col s12 ">
                    <h5 class="green-text text-darken-3">Datum nastanka:<span style="color:black;"><?php echo e($storitev->created_at); ?></span></h5>
                </div>
                <div class="col s12 l8">
                    <h5 class="green-text text-darken-3">Kategorija: <span style="color:black;"><?php echo e($storitev->k_naziv); ?></span></h5>
                </div>
                <div class="col s12 l8">
                    <h5 class="green-text text-darken-3">Regija: <span style="color:black;"><?php echo e($storitev->r_naziv); ?></span></h5>
                </div>
                <div class="col s12 l8">
                    <h5 class="green-text text-darken-3">Ocena: <span style="color:black;"><?php echo e($storitev->avg_ocena); ?></span></h5>
                </div>
                
                
            </div>
            <img src="storage/cover_images/<?php echo e($storitev->slika); ?>" style="width:10em;height:10em;"></img>

        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="divider">    
    </div>
    <h5>Kategorija:  <?php echo e(isset($kategorija) ? $kategorija : "Vnesite kategorijo"); ?></h5>
    <h5>Kraj:  <?php echo e(isset($kraj) ? $kraj : "Vnesite kraj"); ?></h5>
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.Lfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>