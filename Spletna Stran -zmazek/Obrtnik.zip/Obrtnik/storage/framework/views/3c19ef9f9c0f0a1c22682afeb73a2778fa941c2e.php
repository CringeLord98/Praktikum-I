<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Iskanje</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?>
    Iskanje
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>

      <div class="row">
        <div style="height:5em;">

        </div>
        <div class="col s10 offset-s1">
                <form class="col s12" action="<?php echo e(route('IskanjeMain')); ?>" method="POST" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo e(csrf_field()); ?>

                <div class="row">
                    
                    <div class="col s6 input-field">
                            <i class="material-icons prefix">search</i>
                            <input id="icon_prefix" type="text" class="validate" name="kategorija">
                            <label for="icon_prefix">Kategorija</label>
                    </div>
                    <div class="col s6 input-field">
                        <i class="material-icons prefix">location_on</i>
                        <input id="icon_prefix" type="text" class="validate" name="kraj">
                        <label for="icon_prefix">Kraj</label>
                </div>
                <div class="input-field col s12">
                        <select>
                              <option id="dis" value="" disabled selected>Izberi svojo odločitev</option>
                              <option value="">Kebab</option>
                              <option value="2">Option 2</option>
                              <option value="3">Option 3</option>
                            </select>
                            <label>Materialize Select</label>
                          </div>   
                       
                </div>
                <div class="row">
                    <div class="col s4">   
                    </div>
                    <div class="col s6">
                            <button class="btn waves-effect waves-light btn-large btnMegaSearch" type="submit" name="action">
                                Išči
                            </button>
                    </div>     
                </div>
            </form>
        </div>
      </div>
      <div class="divider">    
    </div>
    <h5>Kategorija:  <?php echo e(isset($kategorija) ? $kategorija : "Vnesite kategorijo"); ?></h5>
    <h5>Kraj:  <?php echo e(isset($kraj) ? $kraj : "Vnesite kraj"); ?></h5>
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.Lfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>