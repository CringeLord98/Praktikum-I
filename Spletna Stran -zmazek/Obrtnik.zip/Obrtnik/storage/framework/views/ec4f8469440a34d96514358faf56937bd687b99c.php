<?php $__env->startSection('Content'); ?>
<div style="min-height:44.2em;">
      <div class="row">
        <div style="height:5em;">

        </div>
        <div class="col s10 offset-s1">
                <div class="row">
                        <form class="col s12" action="<?php echo e(route('store')); ?>" method="POST" type="hidden" name="_token">
                        <?php echo e(csrf_field()); ?>

                          <div class="row">
                            <div class="input-field col s6">
                              <i class="material-icons prefix">account_circle</i>
                              <input id="icon_prefix" type="text" class="validate" name="naziv">
                              <label for="icon_prefix">First Name</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s6">
                              <i class="material-icons prefix">account_circle</i>
                              <textarea id="icon_prefix" type="text" class="validate" name="opis"></textarea>
                              <label for="icon_prefix">Opis</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s6">
                              <i class="material-icons prefix">account_circle</i>
                              <select id="icon_prefix" type="text" class="validate" name="kategorija"> <option value="volvo">Volvo</option></select>
                              <label for="icon_prefix">Opis</label>
                            </div>
                          </div><br>
                          <button class="btn waves-effect waves-light" type="submit" name="action">Submit
                                <i class="material-icons right">send</i>
                              </button>
                        </form>
                      </div>
        </div>
      </div>
      <div class="divider">
        
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>