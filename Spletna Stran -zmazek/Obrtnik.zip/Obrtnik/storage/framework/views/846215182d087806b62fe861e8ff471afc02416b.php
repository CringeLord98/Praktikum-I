<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
Storitve
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>
<div class="container white" id="mainContainer" style="min-height:42.7em;">

        <?php if($errors->any()): ?>
        <script>Materialize.toast('<?php echo e($errors->first()); ?>', 4000,'green darken-3')</script>
        <?php endif; ?>  
<div class="row" style="height:1em;"></div>
<?php if(count($storitve)>0): ?>     
        <?php $__currentLoopData = $storitve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storitev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
    <div class="row">
            <div class="col s12 l8 offset-l2">
              <div class="card white lighten-4 hoverable" style="border:1px solid #2e7d327c;">
                <div class="card-content grey-text text-darken-3">
                  <span class="card-title green-text text-darken-3"><?php echo e($storitev->naziv); ?></span>
                  <div class="row">
                      <div class="col l6 s12">
                        <b>Kategorija:</b><p><?php echo e($storitev->k_naziv); ?></p>
                      </div>
                      <div class="col l6 s12">
                        <b>Datum nastanka:</b><p><?php echo e(Carbon\Carbon::parse($storitev->created_at)->format('d.m.Y')); ?></p>
                        </div>
                        
                  </div>
                  
                </div>
                <div class="card-action">
                    <div class="row">
                        <div class="col s6 left-align">
                                <form action="<?php echo e(route('destroy', $storitev->id)); ?>" method="POST" type="hidden" name="_token">
                                        <?php echo e(csrf_field()); ?>

                                <?php echo e(Form::hidden('_method','DELETE')); ?>

                                <button href="<?php echo e(url('/narocilo')); ?>" type="submit" class="waves-effect waves-light btn btn-large btn-Cancle"><i class="material-icons left">delete</i>Izbriši</button>
                                </form>     
                        </div>
                        <div class="col s6 right-align">
                                <a href="/storitve/<?php echo e($storitev->id); ?>/edit" class="waves-effect waves-light btn btn-large"><i class="material-icons left">edit</i>Uredi</a> 
                        </div>
                    </div>
                        
                    
                </div>
              </div>
            </div>
          </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div style=margin-top:5em;margin-bottom:3em;>
    <h5 class="grey-text text-darken-3 center-align">Nimate storitev.</h5>
<div>
<?php endif; ?>




<div class="divider" style="width:80%;margin:auto;"></div>  
<div style="margin-top:2em;">
</div>
<div class="row">
    <div class="col s12 center-align">
            <a href="<?php echo e(url('/storitve/create')); ?>"class="btn btn-floating pulse tooltipped" data-position="bottom" data-delay="50" data-tooltip="Dodaj storitev!"><i class="material-icons">add</i></a>
    </div>
</div>
            
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>