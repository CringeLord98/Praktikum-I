<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>


    
<div class="row" style="height:1em;"></div>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
    
   
</div>


<div style="margin-top:5em;">
</div>
  


            

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>