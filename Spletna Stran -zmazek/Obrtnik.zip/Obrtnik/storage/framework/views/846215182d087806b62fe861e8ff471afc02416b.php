<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>


    
<div class="row" style="height:1em;"></div>
<?php if(count($storitve)>0): ?>     
        <?php $__currentLoopData = $storitve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storitev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto;margin-bottom:3em;">
            <div class="row" style="margin-bottom:0;">
                <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Storitev: <span style="color:black;"><?php echo e($storitev->naziv); ?></span></h5>
                </div>
            </div>
            <div class="divider">

            </div>
            <div class="row">
                <div class="col s12 ">
                    <h5 class="green-text text-darken-3">Datum nastanka:<span style="color:black;"><?php echo e($storitev->created_at->toDateString()); ?></span></h5>
                </div>
                <div class="col s12 l8">
                    <h5 class="green-text text-darken-3">Kategorija: <span style="color:black;"><?php echo e($storitev->kategorija_id); ?></span></h5>
                </div>
                
                <div class="col s12 l2">
                    <a href='/storitve/<?php echo e($storitev->id); ?>/edit' class="waves-effect waves-light btn btn-large">Uredi</a>
                </div>
                <form action="<?php echo e(route('destroy', $storitev->id)); ?>" method="POST" type="hidden" name="_token">
                        <?php echo e(csrf_field()); ?>

                <?php echo e(Form::hidden('_method','DELETE')); ?>

                <div class="col s12 l2">
                    <button href="<?php echo e(url('/narocilo')); ?>" type="submit" class="waves-effect waves-light btn btn-large btn-Cancle">Izbriši</bnutton>
                </div>
                </form>  
                
            </div>
            

        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div style=margin-top:5em;margin-bottom:3em;>
    <h5 class="grey-text text-darken-3 center-align">Nimate storitev.</h5>
<div>
<?php endif; ?>




<div class="divider" style="width:80%;margin:auto;"></div>  
<div style="margin-top:2em;">
</div>
<div class="row">
    <div class="col s12 center-align">
        <a href="<?php echo e(url('/storitve/create')); ?>" class="waves-effect waves-light btn btn-large">Dodaj storitev</a>
    </div>
</div>
            

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>