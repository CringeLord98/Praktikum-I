<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Spremeni profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>

<div class="row" style="height:5em;"></div>
<div class="grey lighten-4 z-depth-2" style="width:80%;margin:auto;">
<div class=" card" style="width:100%;margin:auto;">
                <div class="card-tabs">
                  <ul class="tabs tabs-fixed-width">
                    <li class="tab"><a class="active" href="#PSosnovno">Osnovno</a></li>
                    <li class="tab"><a  href="#PSemail">E-Mail</a></li>
                    <li class="tab"><a href="#PSgeslo">Geslo</a></li>
                    <li class="tab"><a href="#PSslika">Slika</a></li>
                  </ul>
                </div>
                <div class="card-content grey lighten-4">
                <form class="col s12" action="" method="POST" type="hidden" name="_token">
                  <div id="PSosnovno">
                    <div class="row">
                        <div class="col s10 l6">
                                <div class="input-field">
                                        <input id="label123"type="text" class="validate" name="name" placeholder="<?php echo e(Auth::user()->name); ?>">
                                        <label for="label123">Ime</label>
                                      </div>
                        </div>
                        <div class="col s10 l6">
                                <div class="input-field">
                                        <input  id="label123"type="text" class="validate" name="surname" placeholder="<?php echo e(Auth::user()->surname); ?>">
                                        <label for="label123">Priimek</label>
                                      </div>
                            </div>
                    </div>
                    <div class="row">
                            <div class="col s10 l6">
                                    <div class="input-field">
                                            <input id="label123" type="text" class="validate" name="davcna" placeholder="<?php echo e(Auth::user()->davcna); ?>">
                                            <label for="label123">Davčna številka</label>
                                          </div>
                            </div>
                            <div class="col s10 l6">
                                    <div class="input-field">
                                            <input  id="label123" type="text" class="validate" name="telefon" placeholder="<?php echo e(Auth::user()->telefon); ?>">
                                            <label for="label123">Telefonska številka</label>
                                          </div>
                                </div>
                        </div>
                        <div class="row">
                                <div class="col s10 l12">
                                        <textarea  class="materialize-textarea" name="opis" data-length="180" id="txtarea" placeholder="<?php echo e(Auth::user()->opis); ?>"></textarea>
                                        <label for="txtarea">Opis</label>
                                </div>
                            </div>
                  </div>
                  <div id="PSemail">
                        <div class="row">
                                <div class="col s10 l6">
                                        <div class="input-field">
                                                <input id="label123" type="text" class="validate" name="email" placeholder="<?php echo e(Auth::user()->email); ?>">
                                                <label for="label123">Email</label>
                                              </div>
                                </div>
                                <div class="col s10 l6">
                                        <div class="input-field">
                                                <input id="label123" type="text" class="validate" name="email2">
                                                <label for="label123">Ponovite Email</label>
                                              </div>
                                    </div>
                            </div>
                  </div>
                  <div id="PSgeslo">
                        <div class="row">
                                <div class="col s10 l6">
                                        <div class="input-field">
                                                <input id="password" type="password" class="validate" name="email" >
                                                <label for="password"><?php echo e(__('Geslo')); ?></label>
                                              </div>
                                </div>
                                <div class="col s10 l6">
                                        <div class="input-field">
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
                                                <label for="password-confirm"><?php echo e(__('Ponovi Geslo')); ?></label>
                                            </div>
                                    </div>
                            </div>
                  </div>
                  <div id="PSslika">
                        <div class="file-field input-field">
                                <div class="btn">
                                <span>File</span>
                                <input type="file">
                                </div>
                                <div class="file-path-wrapper">
                                <input class="file-path validate" type="text" name="slika">
                                </div>
                        </div>
                  </div>
                
                </div>
    </div>
    
    
</div>
<div class="row" style="height:5em;"></div>
<div class="row" style="height:5em;margin:auto;width:40%;">
    <a href="<?php echo e(url('/profile')); ?>" class="z-depth-2 col s5 btn btn-large btn-cancle waves-effect waves-light"  >
       Prekliči
    </a>
    <button class="z-depth-2 col s5 offset-s1 btn btn-large waves-effect waves-light" >
       Shrani
    </button>
</form>
</div>    

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>