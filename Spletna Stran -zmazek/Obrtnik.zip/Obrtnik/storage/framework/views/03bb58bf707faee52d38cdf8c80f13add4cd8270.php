<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>


    
<div class="row" style="height:1em;"></div>

<form action="<?php echo e(route('update', $storitev->id)); ?>" method="POST" type="hidden" name="_token"   enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
    <div class="row">
            <div class="input-field col s10 offset-s1">
                <input id="first_name" type="text" class="validate" name="naziv" value="<?php echo e($storitev->naziv); ?>">
                <label for="first_name">Naziv</label>
              </div>
        
    </div>
    <div class="row">
            <div class="input-field col s10 offset-s1">
                  <textarea id="textarea1" class="materialize-textarea" name="opis"><?php echo e($storitev->opis); ?></textarea>
                  <label for="textarea1">Opis</label>
            </div>
    </div>
    <div class="row">
        <div class="input-field col s10 offset-s1">
            <div>
                <select name="kategorija">
                        
                        <?php $__currentLoopData = $kategorije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kategorija->id); ?>"><?php echo e($kategorija->naziv); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </select>
            </div>   
            
        </div>
    </div>
        <div class="row">
                <div class="file-field input-field col s10 offset-s1">
                    <div class="btn">
                          <span>Slika</span>
                          <input type="file"  name="slika"  >
                          </div>
                          <div class="file-path-wrapper">
                          <input class="file-path validate" type="text"placeholder="Izberite sliko">
                    </div>
                </div>
        </div>
        <?php echo e(Form::hidden('_method','PUT')); ?>

        <div class="row">
                <div class="col s12 l2 offset-l9">
                        <button type="submit"class="waves-effect waves-light btn btn-large">Končano</button>
                </div>
        </div>
       
    </div>
    
</form>


<div style="margin-top:5em;">
        
</div>
  


            

<?php $__env->stopSection(); ?>











<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>