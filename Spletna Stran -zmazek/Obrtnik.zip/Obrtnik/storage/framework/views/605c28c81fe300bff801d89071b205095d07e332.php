<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Prijava</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?>
    Prijava
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>
<div class="container">
    <div class="login z-depth-5">
            <div class="container">
                    <div style="height:4em;margin-top:1em;">
                        
                    </div>
                    <?php echo MaterialForm::open(array('action' => 'LoginController@Login', 'method'=>'POSTT')); ?>

                    <div class="row">
                        <div class="col s12">
                        <?php echo MaterialForm::text('Uporabniško ime', 'ime')->required()->icon("account_circle"); ?> 
                        </div>
                        
                    </div>
                    <div class="row">
                            <div class="col s12">
                            <?php echo MaterialForm::password('Geslo', 'geslo')->required()->icon("vpn_key"); ?> 
                            </div>
                            
                        </div>
                    
                   
                    <div class="row">
                            <div class="col s4">
                            
                            </div>
                            <div class="col s6">
                                <?php echo MaterialForm::submit("Prijavi")->addClass("btn btn-large btnReg"); ?>

                            </div>
                    </div>
                    
                    <?php echo MaterialForm::close(); ?>

                   
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.LregLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>