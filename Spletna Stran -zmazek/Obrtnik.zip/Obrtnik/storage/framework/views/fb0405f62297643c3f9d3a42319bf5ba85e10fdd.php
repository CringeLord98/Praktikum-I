<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>

<a href='/storitve/create'>create</a>
    <table>
        <tr>
            <th>Title</th>
            <th></th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $storitve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storitev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($storitev->naziv); ?></th>
            <th><a href='/storitve/<?php echo e($storitev->id); ?>/edit'>edit</a></th>
            <th>
                <form action="<?php echo e(route('destroy', $storitev->id)); ?>" method="POST" type="hidden" name="_token">
                <?php echo e(csrf_field()); ?>

                    <?php echo e(Form::hidden('_method','DELETE')); ?>

                    <button class="btn waves-effect waves-light" type="submit" name="action">Submit
                                <i class="material-icons right">send</i>
                              </button>
                </form>  
            </th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </table>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>