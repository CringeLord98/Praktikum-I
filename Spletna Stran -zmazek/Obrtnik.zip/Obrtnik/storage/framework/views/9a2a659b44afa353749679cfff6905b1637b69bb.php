    <?php $__env->startSection('Title'); ?>
        <title>Moj Obrtnik | Iskanje</title>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('Logo'); ?>
    Objave
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('Content'); ?>
    <div class="row">
        <div style="height:1em;margin-top:1em;">
                
        </div>
    </div>
<div class="row">
    <div class="col s12" id="iskanjeTop" >
        <div class="row">
                <?php echo MaterialForm::open(array('action' => 'SearchController@IndexSearch', 'method'=>'POST')); ?>

                <div class="row">
                    <div class="col s5 offset-s1">
                      <?php echo MaterialForm::text('Kategorija', 'kategorija')->required()->icon("search"); ?> 
                    </div>
                    <div class="col s5">
                        <?php echo MaterialForm::text('Kraj', 'kraj')->required()->icon("location_on"); ?> 
                    </div>
                    
                </div>
        <div class="row">
            <!--
            <div class="col s9 offset-s1">
                <div class="col s3" id="searchBox">
                    <h5>Razvrsti po priljubljenosti:</h5>
                    <?php echo MaterialForm::select('Color', 'color')->options(['red' => 'Red', 'green' => 'Green'])->select('green'); ?>

                </div>
                <div class="col s3" id="searchBox">
                    <h5>Razvrsti po datumu:</h5>
           
                </div>
                <div class="col s3" id="searchBox">
                    <h5>Razvrsti po skupinah:</h5>
           
                </div>
            </div>
        -->
            <div class="col s1">
                <?php echo MaterialForm::submit("Išči")->addClass("btn btn-large"); ?>

            </div>
        </div>
        
                <?php echo MaterialForm::close(); ?>

    </div>
    </div>
    
</div>


<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>