<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>


    
<div class="row" style="height:1em;"></div>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
    <div class="row" style="margin-bottom:0;">
        <div class="col s12 l6">
            <h5 class="green-text text-darken-3">Naziv storitve: <span style="color:black;">Mizarstvo Matjaz</span></h5>
        </div>
        <div class="col s9 l3 offset-l3">
                <h5 class="green-text text-darken-3">Številka naročila: <span style="color:black;">1</span></h5>
            </div>
    </div>
    <div class="divider">

    </div>
    <div class="row">
        <div class="col s12 l12">
            <h5 class="green-text text-darken-3">Naročnik: <span style="color:black;">Ana Jelen</span></h5>
        </div>
        
        <div class="col s12 l12">
            <h5 class="green-text text-darken-3">Datum naročila: <span style="color:black;">25.7.2017</span></h5>
         </div>
        <div class="col s12 l9">
            <h5 class="red-text text-darken-3">Datum roka: <span style="color:black;">25.10.2017</span></h5>
         </div>
         <div class="col s12 l3">
                <a href="<?php echo e(url('/narocilo')); ?>" class="waves-effect waves-light btn btn-large">Podrobnosti</a>
             </div>
        
    </div>
    

</div>


<div style="margin-top:5em;">
        <h5 class="grey-text text-darken-3 center-align">Nimate naročil.</h5>
</div>
  


            

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>