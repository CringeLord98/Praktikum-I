<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Profil</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?> 
<?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>

<div class="row" style="height:1em;"></div>
<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto;">
    <div class="row">
        <div class="col s4">
            <div style="margin:3em;">
                <div class="Pimg" >
                    <img class="Pimg"src="storage/cover_images/<?php echo e($user->slika); ?>" style="border:2px solid #2e7d32;">
                </div>
            </div>
        </div>
        <div class="col s8">
                <div class="row" style="height:1em;">
                </div>
                    <div class="row">
                        <div class="col s6">
                            <h5 class="green-text text-darken-2">Ime:</h5>
                            <h5><?php echo e(Auth::user()->name); ?></h5>
                        </div>
                        <div class=" col s6">
                                <h5 class="green-text text-darken-2">Priimek:</h5>
                                <h5><?php echo e(Auth::user()->surname); ?></h5>
                            </div>
                    </div>
                    
                    <div class="row">
                           <civ class="row"></civ>
                            <div class="col s6">
                                <h5 class="green-text text-darken-2">Davčna številka:</h5>
                                <h5><?php echo e(Auth::user()->davcna); ?></h5>
                            </div>
                            <div class=" col s6">
                                </div>
                        </div>
                    <div class="row">
                            
                    </div>
            </div>  
        </div>
        <div class="divider">
            
        </div>
        <div class="row">
                <div class="col s12 ">
                        <div class="row" style="height:1em;">
                        </div>
                            <div class="row">
                                <div class="col s10 offset-s1">
                                    <h5 class="green-text text-darken-2">Opis:</h5>
                                    <p><?php echo e(Auth::user()->opis); ?></p>
                                   </div>
                               
                            </div>
                    </div>  
                </div>
        <div class="divider">

        </div>
        <div class="row">
                <div class="col s12">
                        <div class="row" style="height:1em;"></div>
                                <div class="row">
                                    <div class="col s8 offset-s1">
                                            <div class="input-field col s4">
                                                    <h5 class="green-text text-darken-2">Email:</h5>
                                                    <p><?php echo e(Auth::user()->email); ?></p>
                                            </div>
                                            <div class="input-field col s4">
                                                    <h5 class="green-text text-darken-2">Telefon:</h5>
                                                    <p><?php echo e(Auth::user()->telefon); ?></p>
                                                </div>
                                    </div>
                                    <div class="col s2">
                                            <a href="<?php echo e(url('/profileSettings')); ?>" class="waves-effect waves-light btn btn-large">Spremeni račun</a>
                               </div>
                                   
                        </div>   
                </div>
            </div>

</div>
            

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>